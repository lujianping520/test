package com.haina.Finterface;

public interface FanInterface<T> {

}
